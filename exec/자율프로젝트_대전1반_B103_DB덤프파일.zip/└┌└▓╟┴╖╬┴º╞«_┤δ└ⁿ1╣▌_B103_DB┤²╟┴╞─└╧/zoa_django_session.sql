-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: k7b103.p.ssafy.io    Database: zoa
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('03in8mm24286wvw26r5qskc8zfvwqkww','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1ovqWJ:s0mW8CQ2wtemyPUACmZrBcqpf0KiaqHN4aLyry76mj0','2022-12-02 10:50:19.255133'),('067fmirtbjyd3glgrvmr43n6uy4j3y9l','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1otI0X:D0W6mCGedw8qsgKnZ9eHPE8_NHwKhRpotMAIsaIjzKw','2022-11-25 09:34:57.040954'),('1bbpisx35qjvmwnser0235z5xbrdrp6x','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1oqqOs:k8vY8UicthJ_xQY9cx6vfFSNfWF4DPhsYUz6FwVoSkY','2022-11-18 15:41:58.137922'),('2dyl4cso9i461sotcelqgdaea0i9x2pf','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1osx4n:cNOoUUAysj4q0VrZ1MmoMbau6Me-93FmgGUhfYhtcBs','2022-11-24 11:13:57.693360'),('4o0l86rfxq685zafxlixybvj7tvppomc','.eJxVjMEOwiAQRP-FsyGsuFA8eu83kGUBqRpISnsy_rtt0oMeZ96beQtP61L82tPspyiuQovTbxeIn6nuID6o3pvkVpd5CnJX5EG7HFtMr9vh_h0U6mVbJyActFGsUbFhBmMdJKItJ7AAwdoBzsEqFwnpghlDZguYnXLaoROfL9MzN0U:1osbxL:W_1IOiWd5kZ7V6rOwQxOmdtriZGG8Lio5xlWoRJr3Ro','2022-11-23 12:40:51.265662'),('4s1b9wv24ian14z639ep9y4sfb4t2o43','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1ovHO1:5zbVFY0ocXgIYR7NG76z47h6F2XaIOSXcgbs9hsx1E8','2022-11-30 21:19:25.481681'),('61weynnhzdfry6goavfso97iei6u2lem','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1otIam:2TPf-V7MelCt38wbAovpIlKN92894jjLac5qOzlJAcE','2022-11-25 10:12:24.469244'),('afpk0kegq03fhs3mhriejy6f738gs55t','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1ovSen:hC9s-oBUAZaLKl02KCH250kHAFfxW-6udPPASLSeAHE','2022-12-01 09:21:29.474979'),('c72hjh60k8vux8cl5gwsc9y0u3o8e0pw','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1ovTRm:_DrhxjVZ_aeT7qdyMgb62R-nPqPXrxC1EVJJ7WKTfe0','2022-12-01 10:12:06.188199'),('c8rfy966cs69jwdwuo5b324wnj3kzsbr','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1ovFdW:v7tLm3wkyJ3iS5u_vgkY5XEO5VgV9WuSkWmpdIVtKxE','2022-11-30 19:27:18.368872'),('chp9sjv7g75kx5fkexgle75v59tsdyu5','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1ovSOT:vy8ufD3tNLGmEj5Zec6kIIA2haSXjU_4-yN9rSXVcu0','2022-12-01 09:04:37.771649'),('evziebb2kdb85jj8nuu88p07o44zx385','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1otNyZ:T5dBoAS48PTn2sc_wxzW8kPvTPRT0jM9py0WQVtMPZ4','2022-11-25 15:57:19.952795'),('h0b95q8kipl3hqxrouds771kyrgs8k3e','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1osaEq:-9N3B5o9zgfSksROLuIWaxn8m5jQOBYU60LR7FewTGg','2022-11-23 10:50:48.840760'),('jeomprvzzmkakbwk07u7l8sc201rq4iw','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1oq72a:75_AagvjNrDUxytytvznaiu1EJFGL6fFou1vDVdBhec','2022-11-16 15:15:56.794846'),('lwghj8fzib6mmt74taylct9gdimw52yk','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1ovaW3:550x37vnVgH4GrIM7xCXiter2Ee7PELAdi3NbSF6_jM','2022-12-01 17:44:59.473366'),('mq6zms92a58256dy0lo4m3osn3d5qoor','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1otOc4:o9ZSCkstokE44rcHxr0L5h9sai_rhBIHl4rhMt7Z1BA','2022-11-25 16:38:08.551793'),('n9k2qdalm00azn1u8fjv79t2gjcj2v8x','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1osczQ:7zVoHHr04nPt-7EFTlP_dZDPqw_IFzhuwgvxCpov-yc','2022-11-23 13:47:04.641932'),('qsa19oouynfa3uujyi1w5sz480br72mp','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1otNDA:5cohbwL1Z7IM5xExgwdBgHJCQMkdrXsFF9ktYjTXVWs','2022-11-25 15:08:20.306961'),('s0m6rvt0zn0zqen5v7fbw039lell2e79','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1osd5H:EeItAXLd8IZKxVS-hbBqddEffvqa88G0GveZKFqA0BM','2022-11-23 13:53:07.261836'),('tnzj0vfgvujtzes22w1ujgzhh4lj764f','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1otOZb:zj9o6Nv01Y2UW_KxZEtDBOW_R8lUsw4QIH-9Tskn6KE','2022-11-25 16:35:35.500002'),('txwf81x5sv76uvjived2tuf7jdihmudn','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1ovaUO:e3IBTJpobF9iB3pjjRhGqf8oS_Lz9ZIpSskmFNOZ8zg','2022-12-01 17:43:16.185826'),('u8kuk1c5eq1nhkgivxhngtlekfizrd5b','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1ovFhR:L1p9Bdg6PGrmor5YtX1yjFpSJ1anwQY5TwKDNR6BOKs','2022-11-30 19:31:21.992776'),('wgkhi4pmys2memvtxiyxv30fvn0pdu0d','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1ot2Ea:v2002mempjZ5SXQeLGSHJDYa-Gm9zXh_IuhMxpoduhg','2022-11-24 16:44:24.984905'),('wih77mih790dtg68cw2hp2mkvlasmidc','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1oqlEk:BuDSkCp75Bu13btxSokRLLey5-HXFyCdr_jFfLdBD7U','2022-11-18 10:11:10.300949'),('xpptcfz1el8qwee7lnvk6p5baqpy4vwv','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1otI10:PedNo1z3vmUmSzBQ6EJq4a4-9mNyL8yugS35bNRLZ8I','2022-11-25 09:35:26.525823'),('ysi0uawwlrv1dulv7i4viob7u66dmxjw','.eJxVjDsOwjAQBe_iGlnB_1DS5wzWrneNA8iW4qRC3B0ipYD2zcx7iQjbWuLWeYkziYvw4vS7IaQH1x3QHeqtydTquswod0UetMupET-vh_t3UKCXb50w8MDZG8uchxAcjWci0KwdEaqAPo0ZvNMeIJMlUqAwWRec0YoMiPcHH2c5Mw:1orWam:esM3-5Imi4kvHi8BAr3qPDrrc_rBMiTydAswemCe2L4','2022-11-20 12:45:04.391349');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-18 17:51:46
