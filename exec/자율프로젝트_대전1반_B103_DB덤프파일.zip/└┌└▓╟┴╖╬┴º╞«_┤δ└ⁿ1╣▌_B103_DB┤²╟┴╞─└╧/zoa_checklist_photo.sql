-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: k7b103.p.ssafy.io    Database: zoa
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `checklist_photo`
--

DROP TABLE IF EXISTS `checklist_photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `checklist_photo` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checklist_photo`
--

LOCK TABLES `checklist_photo` WRITE;
/*!40000 ALTER TABLE `checklist_photo` DISABLE KEYS */;
INSERT INTO `checklist_photo` VALUES (1,'checklist/photo/success.jpg'),(2,'checklist/photo/로직_부적.png'),(3,'checklist/photo/구현_부적.png'),(4,'checklist/photo/구현_부적.png'),(5,'checklist/photo/bohCZI.jpg'),(6,'checklist/photo/nVJS0G.jpg'),(7,'checklist/photo/l74rRF.jpg'),(8,'checklist/photo/RlMhec.jpg'),(9,'checklist/photo/RlMhec.jpg'),(10,'checklist/photo/UvqcUH.jpg'),(11,'checklist/photo/UvqcUH.jpg'),(12,'checklist/photo/success.jpg'),(13,'checklist/photo/success.jpg'),(14,'checklist/photo/success.jpg'),(15,'checklist/photo/success.jpg'),(16,'checklist/photo/success.jpg'),(17,'checklist/photo/success.jpg'),(18,'checklist/photo/success.jpg'),(19,'checklist/photo/success.jpg'),(20,'checklist/photo/success.jpg'),(21,'checklist/photo/success.jpg'),(22,'checklist/photo/success.jpg'),(23,'checklist/photo/구현_부적.png'),(24,'checklist/photo/544490D6-C756-4003-A659-095357CC4766.jpg'),(25,'checklist/photo/544490D6-C756-4003-A659-095357CC4766.jpg'),(26,'checklist/photo/544490D6-C756-4003-A659-095357CC4766.jpg'),(27,'checklist/photo/544490D6-C756-4003-A659-095357CC4766.jpg'),(28,'checklist/photo/A23F78A5-1A02-4460-B966-D6338C4C4DBE.png'),(29,'checklist/photo/A23F78A5-1A02-4460-B966-D6338C4C4DBE.png'),(30,'checklist/photo/A23F78A5-1A02-4460-B966-D6338C4C4DBE.png'),(31,'checklist/photo/A23F78A5-1A02-4460-B966-D6338C4C4DBE.png'),(32,'checklist/photo/726413BF-BD3F-442F-8654-C64B5508DBBF.png'),(33,'checklist/photo/726413BF-BD3F-442F-8654-C64B5508DBBF.png'),(34,'checklist/photo/726413BF-BD3F-442F-8654-C64B5508DBBF.png'),(35,'checklist/photo/KakaoTalk_20221106_212045991.jpg'),(36,'checklist/photo/git-cz.png'),(37,'checklist/photo/로직_부적.png'),(38,'checklist/photo/246Ahe.jpg'),(39,'checklist/photo/image.jpg'),(40,'checklist/photo/C45865BD-F681-424F-B7C5-B859A7B67EAB.jpeg'),(41,'checklist/photo/C45865BD-F681-424F-B7C5-B859A7B67EAB.jpeg'),(42,'checklist/photo/C45865BD-F681-424F-B7C5-B859A7B67EAB.jpeg'),(43,'checklist/photo/대전_1반_김동완.JPG'),(44,'checklist/photo/오리엔테이션.pdf'),(45,'checklist/photo/커비.png'),(46,'checklist/photo/커비.png'),(47,'checklist/photo/커비.png'),(48,'checklist/photo/challenge_fighting.png'),(49,'checklist/photo/challenge_fighting.png'),(50,'checklist/photo/MmtpVP.jpg'),(51,'checklist/photo/nzxIzm.jpg'),(52,'checklist/photo/ROMRPs.jpg'),(53,'checklist/photo/부트캠프_일정.PNG'),(54,'checklist/photo/부트캠프_일정.PNG'),(55,'checklist/photo/잼민유지.jpg'),(56,'checklist/photo/잼민유지.jpg'),(57,'checklist/photo/beautiful-dog-listening-looking-up.jpg'),(58,'checklist/photo/Screenshot_20221112_150353.jpg'),(59,'checklist/photo/A65A9C10-D0B0-42D5-843E-883BAC4709E8.jpeg'),(60,'checklist/photo/IMG_20220925_161344_602.jpg'),(61,'checklist/photo/404.png'),(62,'checklist/photo/l8VZ2N.jpg'),(63,'checklist/photo/222.png'),(64,'checklist/photo/666.png'),(65,'checklist/photo/666.png'),(66,'checklist/photo/666.png'),(67,'checklist/photo/logo.png'),(68,'checklist/photo/Mc9Hmo.jpg'),(69,'checklist/photo/DLpaud.jpg'),(70,'checklist/photo/E5F6C494-83B5-4AC8-87DA-3E030A945B16.jpeg'),(71,'checklist/photo/vue.png'),(72,'checklist/photo/가오다인.png'),(73,'checklist/photo/neMBx9.jpg'),(74,'checklist/photo/htIWch.jpg'),(75,'checklist/photo/sarBwE.jpg');
/*!40000 ALTER TABLE `checklist_photo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-18 17:51:44
