-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: k7b103.p.ssafy.io    Database: zoa
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_user`
--

DROP TABLE IF EXISTS `accounts_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_user` (
  `password` varchar(128) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `phone` varchar(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `birth` date NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `kakao_id` varchar(30) DEFAULT NULL,
  `family_id_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`),
  UNIQUE KEY `kakao_id` (`kakao_id`),
  KEY `accounts_user_family_id_id_c69f5e75_fk_families_family_id` (`family_id_id`),
  CONSTRAINT `accounts_user_family_id_id_c69f5e75_fk_families_family_id` FOREIGN KEY (`family_id_id`) REFERENCES `families_family` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_user`
--

LOCK TABLES `accounts_user` WRITE;
/*!40000 ALTER TABLE `accounts_user` DISABLE KEYS */;
INSERT INTO `accounts_user` VALUES ('pbkdf2_sha256$260000$KVYqr8feTNQqj2BD5DzQby$8NxpPMt+qkgw2baAFRW+Et5bu5C1KI/5rbnstdjuVcU=',0,0,1,1,'01027064284','김민정','1996-11-05','user/profile/20220117_000855.jpg',NULL,10),('pbkdf2_sha256$260000$uEqTJXRMxQkwT1GMgPdkcW$AzAjZ8Usplu/ClUQA0splBEmepnU1lAn+LcR+V9eS38=',1,1,1,3,'01041885145','박호현','2022-11-02','user/profile/D0ABC1CF-D85E-4A4B-991C-132408024C07.jpeg',NULL,10),('pbkdf2_sha256$260000$5uYRT5WqhRbjEizAZifE9t$0FPhFDCFMxTShyewXOTq7JG6GR934EszFtGetfnaXqM=',0,0,1,4,'01012341234','호현테스트용1','2022-11-02','user/profile/profile_default1.png',NULL,2),('pbkdf2_sha256$260000$jcj4ww5oo7Oga2bSry9l4W$SSaAALh84Z20clkfpmdbc7LnVbjKqBh6JJty1Opg9yw=',0,0,1,5,'01046509261','김동완','2022-11-02','user/profile/vue.png',NULL,NULL),('pbkdf2_sha256$260000$FMiQuo3tCial1jvX2WfEqj$4y+Qvgq7hNsAXAxAWCd8eeGttiXi0oVH5zvw0oPjKVA=',0,0,1,6,'01056785678','호현테스트용2','2022-11-02','user/profile/profile_default1.png',NULL,2),('pbkdf2_sha256$260000$lDZCY8xuES6kDwrZRvPOaW$KjPnGv2MMvFJr7k6OYRBG7jygTHLR/oZ1gvh+hxeUWQ=',1,1,1,7,'0100000000','김동완','1997-11-19','user/profile/profile_default1.png',NULL,NULL),('pbkdf2_sha256$260000$gkI5cgMoiYvLpfRsbfy9ak$yal8twYFG98CIpCetJqB/pLTHppxsDEJHT3uuu/Y+tQ=',0,0,1,8,'01030157109','김수안무','1996-11-17','user/profile/metamask-fox.png',NULL,3),('pbkdf2_sha256$260000$ZtR3402tlOFGx3maIoXDIk$HsMnzofhS6WrhFH+MLdgKtdqUq3XT5e3k6h9HyXimeY=',0,0,1,9,'01000000000','민정쓰','1996-11-05','user/profile/profile_default1.png',NULL,NULL),('pbkdf2_sha256$260000$LVaVEGIA617xHFZPf2ROJD$Y0S6As0Rl7jxlh5UIM9M2dljchWeNKQzm4TgUwtXslw=',0,0,1,10,'01000000001','민정이','1996-11-10','user/profile/profile_default1.png',NULL,NULL),('pbkdf2_sha256$260000$vMUuxPYJDJWFzW0rPGmr83$BA6J6/E1UuHYZ3lEDikTE/Rh+NwRA22VPt0twdTs4N8=',0,0,1,13,'01000000002','김토끼002','1999-12-31','user/profile/111.jpg',NULL,NULL),('pbkdf2_sha256$260000$l2R3oXJZ3XhtxB2cMHYf1l$PGXAAhgZkS7vbZTC1coDiJcdZeXXbfrGemoz4R0RBpw=',0,0,1,14,'01011112222','test1','1234-12-12','user/profile/profile_default1.png',NULL,5),('pbkdf2_sha256$260000$Wfc6wqSibjBmk27aIrXEia$kIPOOiskubbXnwh0UFQp+7NBCZF72a6nSLyYG2F6V9Q=',1,1,1,15,'01000001111','ZOA','2022-11-04','user/profile/profile_default1.png',NULL,NULL),('pbkdf2_sha256$260000$q0qOmEA6M94AbqfN3DVFke$T5PFrt57xxpM/bz1Upm3CVJdNDSb7VUr4o2BfnAZNio=',0,0,1,16,'01094962775','박찬','1996-10-21','user/profile/FCADB70B-9774-498D-AA24-D1202E214936.jpeg',NULL,10),('pbkdf2_sha256$260000$H1LKPkutbIAPSv3ARe5DRu$ZRoyGv9Aa/k3pV9sdhlOoZcGPhOG7yv1bWN98Y6KBsA=',0,0,1,17,'01064325283','눈사람','1999-02-12','user/profile/20221112_200200.jpg',NULL,NULL),('pbkdf2_sha256$260000$l9yD5GhuLhe8efyL8YReah$7/NsoRbCh7g+Ycu5cE8E3VSKpawCFW7X1/69ZxtFeSM=',1,1,1,20,'01051007109','재현','1995-03-02','http://k.kakaocdn.net/dn/rZGl1/btrLfNubk2j/3NHFUybY46LOVI9zWmL8lK/img_640x640.jpg','2510938329',NULL),('pbkdf2_sha256$260000$vni5MPuCCvMgpPnb4eblb0$eG+XfoPWX3oP6t343eGqJChvy64eYyuW46sQSQGY8iY=',0,0,1,23,'12312341234','민정이','1996-11-10','user/profile/profile_default1.png',NULL,NULL),('pbkdf2_sha256$260000$Rfn7C0QEUeKayRIK6JfWKz$w5qcufHoz52eH/1gch92KZoEWAxy1DnR5fPDs5/51/k=',0,0,1,24,'99999999999','폰번호테스','1996-11-10','user/profile/profile_default1.png',NULL,NULL),('pbkdf2_sha256$260000$rAvS3kgags5wP3ENoRHLED$Azq0Gip1Mtl3tqje4Nc1opY47Wrq4V/qrny+GqZZUoo=',0,0,1,25,'99999999990','폰번호테스트트트','1996-11-10','user/profile/profile_default1.png',NULL,NULL),('pbkdf2_sha256$260000$TJY4WL9ZKWCwwJVLL7wgJG$aTQMLoiO7LIQwnxDkcppR+R/PFgjk6Ocjq0Wz/I5EuA=',0,0,1,28,'01056565656','test5','1234-12-12','user/profile/profile_default1.png',NULL,NULL),('pbkdf2_sha256$260000$QR9L9DvLgESFeE1agXsgUx$bqP5zu3cVqJXR719RAUnA2oLvcZKDCDtNseXiU3YAAw=',0,0,1,29,'01099997777','김빵빵','2022-11-17','user/profile/profile_default1.png',NULL,NULL),('pbkdf2_sha256$260000$gIXrCSFdggiNUJYDzbLWBh$DLNn95OdHEXBZY4bQ3SnGow0w8CTshXPFZwqp10Lg4I=',0,0,1,41,'01011111111','test','2022-11-11','user/profile/profile_default1.png',NULL,NULL),('pbkdf2_sha256$260000$pTGFRyzLstcTBInpBoRW0U$Bax1s7esADLYWUkx6TXb+3Cf2uowClJEW2HRYIUuXcQ=',0,0,1,42,'01022222222','test','2022-11-11','user/profile/profile_default1.png',NULL,7),('pbkdf2_sha256$260000$DFpqAZDp7yzOBtt9X55v4r$g92ySnwcAvCToXQ9uSJE78tHBFUK1eUD/IRfEYi+hgU=',0,0,1,43,'01000000003','김여우','1992-06-14','user/profile/haha.png',NULL,NULL),('pbkdf2_sha256$260000$HjXNdQnnO5gLVeQHmN3uZu$gSurA0eYA0S3mEfEPu961+9XrOh7cKytAwvs5vJIWxM=',0,0,1,44,'01032884362','김대원','1996-08-17','user/profile/7z4TKm.jpg',NULL,10),('pbkdf2_sha256$260000$VUu5ma2wPiDrgBXCzGcdK9$x0w6lorBcaoekTSAs2boezmFErYPZkAUN5PR44mSNS8=',0,0,1,45,'01065154094','이은경','1998-12-21','user/profile/profile_default1.png',NULL,NULL),('pbkdf2_sha256$260000$B6waXkiiVnNqIXm0aYcqHT$YIuSoO5D0KMpTRZL5whkGZq5y38UFQIbb0+uucUKsBs=',0,0,1,50,'01052857313','조민규','1996-12-18','user/profile/2.png','2526776820',NULL),('pbkdf2_sha256$260000$PzO6z5wCembsNlWghciJOF$vbWaU/4FKsNv1f5AWeEOqzp9FjSY7ela/XIwW7IgC1o=',0,0,1,60,'01050372566','황수환','1967-03-14','user/profile/글의_흐름.png',NULL,9),('pbkdf2_sha256$260000$ML5gbaOOyKhPR9dFSr4LAP$TyoBU3EkaVhwK6wif5MsUFaOKI15O8EksCx/VFBduh8=',0,0,1,61,'01046509260','김동완','2007-01-03','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg','2516864232',NULL),('pbkdf2_sha256$260000$KeSmyyieWHkIs7ZERFTQf0$laDdcey9hco8dMLO0v6wsDWgarTZQyQfZqLS1+rSppo=',0,0,1,62,'01020645283','정아현','1999-02-12','http://k.kakaocdn.net/dn/qHccJ/btrKOh93XHd/MW6htEy8opxHheN7k2WQUK/img_640x640.jpg','2502135322',NULL),('pbkdf2_sha256$260000$0H1ZwztyswMHZ1tqmoEZ6Z$St+T/5aecNHSgcA++f+AOFi4+teqUIa1hgQ3UQFa3Ec=',0,0,1,63,'01095122276','김유진','1992-12-06','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg','2537939796',10);
/*!40000 ALTER TABLE `accounts_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-18 17:51:41
